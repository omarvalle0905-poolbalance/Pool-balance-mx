# 🌊 Pool Balance PWA — Firebase Edition v2.0

> **Gestoría Técnica y Monitoreo de Albercas · Veracruz, México**  
> PWA mobile-first · SPA · Firebase Auth + Firestore · Tailwind CSS

---

## 🏗️ Arquitectura General

```
┌─────────────────────────────────────────────────────────┐
│  GOOGLE SHEETS (Libro Maestro)                          │
│  Datos de campo → Gemini procesa → Apps Script          │
└────────────────────────┬────────────────────────────────┘
                         │  REST API / Admin SDK
                         ▼
┌─────────────────────────────────────────────────────────┐
│  FIREBASE (Google Cloud)                                │
│  ├── Authentication  → Login cliente (ID + PIN)         │
│  ├── Firestore       → Bitácoras, perfiles, lecturas    │
│  └── Storage         → Fotos del servicio               │
└────────────────────────┬────────────────────────────────┘
                         │  Listeners en tiempo real
                         ▼
┌─────────────────────────────────────────────────────────┐
│  POOL BALANCE PWA (Este proyecto)                       │
│  ├── Vista Pública   → Captación de clientes            │
│  └── Portal Cliente  → Dashboard + Bitácoras + PDF      │
└─────────────────────────────────────────────────────────┘
```

---

## ✅ Funcionalidades Implementadas

### Infraestructura
- [x] SPA con router hash (`#home`, `#servicios`, `#biblioteca`, `#portal`)
- [x] PWA instalable (manifest.json + Service Worker offline)
- [x] SEO técnico + Open Graph + Schema.org JSON-LD
- [x] Firebase Authentication (email sintético + PIN)
- [x] Firestore listeners en tiempo real (datos se actualizan sin recargar)
- [x] Modo demo automático si Firebase no está configurado
- [x] Bottom Nav (móvil) ↔ Sidebar (desktop lg+)

### Vista 1 — Home / Informativa
- [x] Hero inmersivo con stats
- [x] 4 tarjetas didácticas del problema
- [x] Método Pool Balance™ (5 pasos)
- [x] Tabla comparativa vs servicio convencional
- [x] CTAs con links de WhatsApp

### Vista 2 — Servicios y Precios
- [x] 3 pricing cards (Esencial / Balance / Premium)
- [x] Add-ons / servicios adicionales
- [x] FAQ accordion
- [x] Proceso de contratación (3 pasos)

### Vista 3 — Biblioteca Técnica / Podcasts
- [x] 6 episodios con reproductor de audio UI
- [x] Waveform interactiva simulada
- [x] Soporte para audio real (URL en config.js)
- [x] Filtros por categoría

### Vista 4 — Portal del Cliente (Firebase)
- [x] Login con ID de Cliente + PIN de 6 dígitos
- [x] Firebase Authentication real
- [x] Dashboard con datos de Firestore en tiempo real
- [x] Historial de bitácoras con score de salud del agua
- [x] Botones de descarga PDF y acceso al detalle

### Bitácora Detallada (EL TRADUCTOR)
- [x] Score de salud del agua (0–100) con ring visual
- [x] Barras de rango óptimo para 8 parámetros
- [x] **Explicaciones didácticas automáticas** según el valor
- [x] Chips de químicos utilizados
- [x] Galería de fotos con lightbox y navegación
- [x] Botón PDF — genera reporte completo en el navegador
- [x] Compartir por WhatsApp con resumen técnico formateado

### Generador de PDF (client-side)
- [x] Header de marca con datos del cliente
- [x] Score visual y estado del agua
- [x] Tabla de parámetros con badges de estado
- [x] Acciones realizadas y químicos aplicados
- [x] Nota del técnico
- [x] Consumo de agua (retrolavados + evaporación)
- [x] Footer institucional

---

## 📁 Estructura de Archivos

```
pool-balance/
│
├── index.html                    ← App shell + SEO + PWA meta
├── manifest.json                 ← Config PWA instalable
├── sw.js                         ← Service Worker offline
├── firebase.json                 ← Config Firebase Hosting (crear tú)
│
├── data/
│   └── config.js                 ⭐ Datos de contenido (textos, paquetes, etc.)
│
├── css/
│   ├── design-system.css         ← Variables, tokens, botones, badges
│   ├── layout.css                ← App shell, sidebar, bottom nav
│   └── components.css            ← Estilos por vista + range bars + galería
│
├── js/
│   ├── app.js                    ← Init, Toasts, FAB, Service Worker
│   ├── router.js                 ← SPA hash router con transiciones
│   │
│   ├── firebase/
│   │   ├── firebase.js           🔥 CONFIGURAR AQUÍ las credenciales
│   │   ├── auth.js               ← Firebase Authentication service
│   │   ├── firestore.js          ← Firestore CRUD + listeners tiempo real
│   │   └── pdf.js                ← Generador PDF client-side (jsPDF)
│   │
│   ├── components/
│   │   └── nav.js                ← Bottom nav + sidebar controller
│   │
│   └── views/
│       ├── home.js               ← Vista 1: Hero + Método
│       ├── servicios.js          ← Vista 2: Pricing + FAQ
│       ├── biblioteca.js         ← Vista 3: Podcasts + Reproductor
│       ├── bitacora-detalle.js   ← EL TRADUCTOR: análisis visual completo
│       └── portal.js             ← Vista 4: Login + Dashboard Firebase
│
├── FIREBASE_SETUP.md             📋 Guía completa de configuración
└── README.md                     ← Este archivo
```

---

## 🔥 Configuración Firebase (PRIMER PASO)

**Editar este archivo con tus credenciales:**
```
js/firebase/firebase.js  →  línea 14  →  const firebaseConfig = { ... }
```

Sigue la guía paso a paso en: **`FIREBASE_SETUP.md`**

---

## 🗂️ Esquema Firestore

```
clientes/{clienteId}/
  ├── nombre, plan, direccion, volumen_m3, proxima_visita...
  └── albercas/{albercaId}/
        └── bitacoras/{YYYY-MM-DD}/
              ├── lecturas: { ph, cloro_libre, cloro_combinado,
              │              alcalinidad, dureza_calcica, lsi,
              │              temperatura, estabilizador }
              ├── acciones: [ "Ajuste pH", "Retrolavado..." ]
              ├── notas, tecnico, estado, fecha
              ├── fotos: [ "https://...", "https://..." ]
              ├── litros_retrolav, litros_evap
              └── quimicos_usados: { acido_mur_lt, cloro_kg, bicarbonato_kg }
```

---

## 🔐 Sistema de Autenticación

| Elemento | Valor |
|---|---|
| Proveedor | Firebase Auth — Email/Password |
| Email sintético | `pb-2025-001@poolbalance.cliente` |
| PIN (contraseña) | 6 dígitos numéricos |
| Quién crea usuarios | Omar (Firebase Console o Apps Script) |
| Seguridad | Reglas Firestore: cada cliente solo lee sus datos |

**Credenciales demo (modo sin Firebase):**
- ID: `PB-2024-0042` · Código: `123456`

---

## 🔗 URIs de Navegación

| Hash | Vista |
|---|---|
| `/#home` | Home / Informativa |
| `/#servicios` | Servicios y Precios |
| `/#biblioteca` | Biblioteca / Podcasts |
| `/#portal` | Login → Dashboard del cliente |

---

## 📊 Parámetros del "Traductor Visual"

| Parámetro | Rango Óptimo | Peso en Score |
|---|---|---|
| pH | 7.2 – 7.6 | 25% |
| Cloro Libre | 1.0 – 3.0 ppm | 25% |
| Cloro Combinado | 0 – 0.3 ppm | 15% |
| Alcalinidad | 80 – 120 ppm | 15% |
| Dureza Cálcica | 200 – 400 ppm | 10% |
| LSI (Langelier) | -0.3 – +0.3 | 10% |
| Temperatura | 24 – 32 °C | Opcional |
| Estabilizador CYA | 30 – 50 ppm | Opcional |

---

## 🔄 Flujo de Trabajo Completo

```
1. Omar hace el servicio en campo
2. Lee los valores con el fotómetro digital
3. Registra en el Libro Maestro de Google Sheets
4. Gemini procesa y completa la bitácora
5. Apps Script exporta automáticamente a Firestore
6. El cliente abre Pool Balance PWA
7. Ve sus datos actualizados en tiempo real
8. Puede descargar el PDF o compartir por WhatsApp
```

---

## 🚀 Deploy en Firebase Hosting

```bash
# Instalar CLI
npm install -g firebase-tools
firebase login

# Inicializar en la carpeta del proyecto
firebase init hosting
# → public directory: .
# → single-page app: Yes

# Desplegar
firebase deploy --only hosting
# → https://pool-balance.web.app
```

Ver guía completa de dominio .mx en `FIREBASE_SETUP.md`

---

## 📋 Próximos Pasos

- [ ] Pegar `firebaseConfig` real en `js/firebase/firebase.js`
- [ ] Crear primer cliente de prueba en Firebase Auth
- [ ] Crear primera bitácora real en Firestore
- [ ] Configurar Apps Script en el Libro Maestro de Sheets
- [ ] Subir primera foto al Storage y pegar URL en Firestore
- [ ] Ejecutar `firebase deploy` y conectar dominio .mx
- [ ] Push notifications para "nueva bitácora disponible"
- [ ] Panel admin interno para crear clientes sin ir a la consola

---

*Pool Balance PWA v2.0 — Firebase Edition*  
*HTML5 + Tailwind CSS + JavaScript Modular + Firebase · Veracruz, México*
