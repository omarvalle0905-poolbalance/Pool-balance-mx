# Pool Balance PWA
## Documento de Marca, Paleta y Arquitectura Técnica
**Versión:** 2.3 — Fase 3 UI Polish completa  
**Fecha:** Mayo 2026  
**Cliente:** Omar Castillo — Técnico en albercas, Veracruz, México

---

## 1. IDENTIDAD DE MARCA

### Nombre y taglines
| Elemento | Texto |
|---|---|
| Nombre | **Pool Balance** |
| Tagline principal | *"Una alberca cristalina no siempre es una alberca segura."* |
| Tagline de marca | *"El activo más valioso es el agua"* |
| Método registrado | Pool Balance™ |
| Ubicación | Veracruz, México |

### Tipografía
| Uso | Fuente | Peso |
|---|---|---|
| Titulares, marca, CTAs | **Bricolage Grotesque** | 800 (ExtraBold) |
| Subtítulos, cuerpo fuerte | Bricolage Grotesque | 600–700 |
| Cuerpo de texto | Bricolage Grotesque | 400–500 |

> Fuente vía Google Fonts. Rango óptico 12–96, ideal para display y texto pequeño.

---

## 2. PALETA DE COLORES OFICIAL

### Los 3 colores principales

```
╔══════════════════════════════════════════════════╗
║  MARINO          CORAL TROPICAL     CRISTAL      ║
║  #0E4569         #E8664A            #6FB8C6       ║
║  Azul profundo   Acento cálido      Agua clara    ║
╚══════════════════════════════════════════════════╝
```

### Tabla completa de tokens de color

| Token | Hex | Uso |
|---|---|---|
| `--color-marino` | `#0E4569` | Fondo principal, texto títulos, sidebar, topbar |
| `--color-marino-dark` | `#0a3350` | Hover botones marino, sombras profundas |
| `--color-marino-light` | `#1a5a82` | Degradados, estados hover suaves |
| `--color-arcilla` (Coral Tropical) | `#E8664A` | CTA principal, acento borde topbar, "Balance" en marca |
| `--color-arcilla-dark` | `#d44f33` | Hover del botón coral |
| `--color-arcilla-light` | `#fde8e3` | Fondos tintados, estados activos suaves |
| `--color-cristal` | `#6FB8C6` | Subtítulos sobre marino, íconos, bordes agua |
| `--color-cristal-dark` | `#5aa3b1` | Encabezado tabla comparativa |
| `--color-cristal-light` | `#d8eff3` | Fondos muy suaves, chips de estadística |
| `--color-bruma` | `#EEF1F5` | Fondo general de la app, secciones alternas |

### Colores semánticos

| Token | Hex | Uso |
|---|---|---|
| `--color-success` | `#2D9E6B` | Agua certificada, acciones positivas |
| `--color-warning` | `#E8A838` | Alertas químicas, LSI, cloro excesivo |
| `--color-danger` | `#D95C5C` | Agua verde, problemas graves |

### Cómo se usa la paleta en la marca

```
Topbar móvil:
  Fondo ──────────────── Degradado Marino → Azul agua
  Borde inferior ─────── Coral Tropical (3px)
  "Pool" ─────────────── Blanco puro
  "Balance" ──────────── Coral Tropical
  Subtítulo ──────────── Cristal

Botón CTA principal:
  Fondo ──────────────── Coral Tropical
  Texto ──────────────── Blanco
  Sombra ─────────────── rgba(232,102,74, 0.30)

Hero de la app:
  Overlay ────────────── Marino 88% opacidad
  Texto ──────────────── Blanco
  Acento cursiva ─────── Cristal claro
  Tag slides ─────────── Verde/Amarillo/Rojo según estado del agua
```

---

## 3. MAPA DE ARCHIVOS DEL PROYECTO

```
pool-balance-pwa/
│
├── index.html                ← Shell principal de la SPA
├── manifest.json             ← Config PWA (nombre, iconos, colores)
├── sw.js                     ← Service Worker (cache offline)
│
├── css/
│   ├── design-system.css     ← Variables, tipografía, tokens globales
│   ├── layout.css            ← Topbar, sidebar, bottom nav, grid
│   └── components.css        ← Hero, carousel, tarjetas, audio, video
│
├── js/
│   ├── app.js                ← Inicialización, toasts, SW, FAB WhatsApp
│   ├── router.js             ← Router hash SPA (PostRender hook)
│   ├── components/
│   │   └── nav.js            ← Navegación inferior + sidebar
│   ├── views/
│   │   ├── home.js           ← Vista principal: carousel, tarjetas, método
│   │   ├── servicios.js      ← Vista de paquetes y precios
│   │   ├── biblioteca.js     ← Vista de podcast/episodios
│   │   └── portal.js         ← Portal del cliente (Firebase Auth)
│   └── firebase/
│       ├── firebase.js       ← Inicialización Firebase SDK
│       ├── auth.js           ← Autenticación de clientes
│       ├── firestore.js      ← Base de datos en tiempo real
│       └── pdf.js            ← Generador de PDFs (jsPDF)
│
├── data/
│   └── config.js             ← ⭐ ÚNICO ARCHIVO QUE EDITA OMAR
│
├── images/
│   ├── logo.png              ← Logo Pool Balance yin-yang agua
│   ├── carousel-1.jpg        ← Slide 1: agua verde / problema
│   ├── carousel-2.jpg        ← Slide 2: agua cristalina LSI
│   ├── carousel-3.jpg        ← Slide 3: medición química
│   ├── carousel-4.jpg        ← Slide 4: alberca perfecta
│   └── LÉEME-FOTOS.md        ← Instrucciones para cambiar fotos
│
├── audios/
│   └── LÉEME-AUDIOS.md       ← Instrucciones + guiones de audio
│
└── assets/
    └── icons/
        ├── icon-72.png        ← Iconos PWA para instalación
        ├── icon-96.png
        ├── icon-128.png
        ├── icon-144.png
        ├── icon-152.png
        ├── icon-192.png
        ├── icon-384.png
        ├── icon-512.png
        ├── icon-192-maskable.png  ← Icono adaptable Android
        └── icon-512-maskable.png
```

---

## 4. COMPONENTES DE LA UI

### Topbar móvil (siempre visible en portrait)
- Alto: **80px** + safe area iOS
- Fondo: **degradado marino → azul agua**
- Borde inferior: **3px coral**
- Logo: **46px circular** con borde cristal
- Tipografía: "Pool" blanco 800 · "Balance" coral · subtítulo cristal

### Bottom Navigation (móvil/tablet)
- Alto: **80px** + safe area iOS
- 4 pestañas: Inicio · Servicios · Biblioteca · Mi Portal
- Estado activo: ícono coral + línea coral arriba + fondo tintado marino
- Desaparece en desktop (sidebar toma su lugar)

### Hero Carousel
- 4 slides con foto de fondo + overlay marino degradado
- Auto-avance cada **5 segundos**, pausa en hover
- Swipe táctil, flechas, dots indicadores
- Tag de escenario (esquina superior derecha): verde/amarillo/rojo
- Caption inferior con stat destacada
- Botón de audio opcional por slide (si hay MP3 en `audios/`)

### Tarjetas didácticas "Lo que nadie te dice"
- 4 tarjetas: Peligro / Advertencia / Información / Éxito
- Barra de color superior (degradado por tipo)
- Número decorativo grande en esquina (CSS `content: attr(data-num)`)
- Ícono con gradiente y sombra de color
- Hover: elevación + ícono rota

### Video promocional (opcional)
- Acepta YouTube, Vimeo o MP4 directo
- Activar: poner URL en `data/config.js → promoVideo.url`
- Oculto por defecto (`url: null`)

---

## 5. SISTEMA DE CONTENIDOS — data/config.js

**Este es el único archivo que debe editar Omar.**  
Contiene en un solo lugar:

| Sección | Qué controla |
|---|---|
| `company` | Nombre, teléfono, WhatsApp, email, horario |
| `seo` | Título de página, descripción, Open Graph |
| `home.hero.slides[]` | Fotos, textos y audio del carousel |
| `home.hero.promoVideo` | Video promocional (on/off con URL) |
| `home.hero.stats[]` | Estadísticas del hero (+200 albercas, etc.) |
| `home.problemSection` | Tarjetas didácticas |
| `home.methodSection` | Pasos del método Pool Balance |
| `home.whySection` | Tabla comparativa convencional vs Pool Balance |
| `servicios` | Paquetes, precios, beneficios |
| `biblioteca` | Episodios de podcast/audio educativo |

---

## 6. SISTEMA DE FOTOS — nombres fijos

Para cambiar una foto: subir el archivo con el nombre exacto a `images/`.  
No hay que tocar código.

| Archivo | Descripción |
|---|---|
| `images/carousel-1.jpg` | Slide 1 — problema de agua (verde, turbia) |
| `images/carousel-2.jpg` | Slide 2 — agua cristalina engañosa (LSI) |
| `images/carousel-3.jpg` | Slide 3 — trabajo técnico, fotómetro |
| `images/carousel-4.jpg` | Slide 4 — alberca perfecta, resultado ideal |
| `images/logo.png` | Logo yin-yang agua — topbar, splash, sidebar |

**Especificaciones:** 1400×900 px mínimo · JPG o WebP · max 500 KB · horizontal

---

## 7. STACK TECNOLÓGICO

| Capa | Tecnología |
|---|---|
| Frontend | HTML5 + CSS3 + JavaScript vanilla (ES2020) |
| Estilos utilitarios | Tailwind CSS (CDN) |
| Íconos | Font Awesome 6 Free |
| Tipografía | Google Fonts — Bricolage Grotesque |
| Base de datos | Firebase Firestore (tiempo real) |
| Autenticación | Firebase Auth (email sintético por cliente) |
| PDFs | jsPDF (generación client-side) |
| PWA | Web App Manifest + Service Worker (Cache First) |
| Routing | SPA hash router personalizado con PostRender hooks |

---

## 8. CÓMO PUBLICAR EN FIREBASE HOSTING

1. Descarga todos los archivos del proyecto
2. Instala Firebase CLI: `npm install -g firebase-tools`
3. En la carpeta del proyecto: `firebase init hosting`
4. Selecciona tu proyecto Firebase existente
5. Carpeta pública: `.` (punto — la raíz)
6. SPA: **Sí**
7. Publicar: `firebase deploy`

Tu app quedará en: `https://TU-PROYECTO.web.app`

> El Service Worker ya está configurado para funcionar correctamente en producción con HTTPS — incluyendo la instalación como PWA nativa en Android/Xiaomi.

---

## 9. CHECKLIST FASE 3 — ESTADO FINAL

| Tarea | Estado |
|---|---|
| Paleta Coral Tropical `#E8664A` aplicada | ✅ |
| Hero carousel 4 slides (auto-avance, swipe, dots) | ✅ |
| Bottom nav mejorado (80px, íconos grandes, labels) | ✅ |
| Logo real `images/logo.png` integrado | ✅ |
| Splash loader con ondas animadas + logo | ✅ |
| iOS safe area respetada | ✅ |
| Sección video promocional (on/off) | ✅ |
| Tipografía mejorada (clamp responsive) | ✅ |
| Tarjetas didácticas v2 (gradiente, número, hover) | ✅ |
| Sistema de audio por slide (play/pause/stop) | ✅ |
| Brand topbar móvil (degradado marino+coral) | ✅ |
| Fotos carousel con nombres fijos (carousel-1 a 4) | ✅ |
| Instrucciones para Omar en `images/LÉEME-FOTOS.md` | ✅ |
| Iconos PWA instalados en `assets/icons/` | ✅ |
| manifest.json listo para instalación nativa | ✅ |
| Marca de agua eliminada (se veía corriente) | ✅ |
| Logo hero eliminado (PNG sin transparencia) | ✅ |

---

*Pool Balance PWA — Documento generado en sesión de desarrollo*  
*Omar Castillo · Veracruz, México · poolbalance.mx*
