# 🔥 FIREBASE SETUP — Pool Balance PWA
## Guía Completa de Configuración · Omar Castillo

---

## ¿QUÉ VAMOS A CONFIGURAR?

```
Firebase Authentication  →  Login de clientes (ID + PIN)
Cloud Firestore          →  Bitácoras, perfiles, lecturas
Firebase Storage         →  Fotos del servicio
Firebase Hosting         →  Dominio .mx con HTTPS
Apps Script (Sheets)     →  Alimenta Firestore automáticamente
```

---

## PASO 1 — CREAR EL PROYECTO FIREBASE

1. Ve a **https://console.firebase.google.com**
2. Inicia sesión con tu cuenta Google One AI Premium
3. Clic en **"Agregar proyecto"**
4. Nombre del proyecto: `pool-balance`
5. **Desactiva** Google Analytics (opcional, puedes activarlo después)
6. Clic en **"Crear proyecto"**

---

## PASO 2 — REGISTRAR LA APP WEB

1. En la consola del proyecto → ícono **`</>`** (Web)
2. Nombre de la app: `Pool Balance PWA`
3. ✅ Activa **"Firebase Hosting"** al mismo tiempo
4. Clic en **"Registrar app"**
5. Verás un bloque de código así:

```javascript
const firebaseConfig = {
  apiKey:            "AIzaSyXXXXXXXXXXXXXXXXXXXXX",
  authDomain:        "pool-balance.firebaseapp.com",
  projectId:         "pool-balance",
  storageBucket:     "pool-balance.appspot.com",
  messagingSenderId: "123456789012",
  appId:             "1:123456789012:web:abcdef1234567890",
  measurementId:     "G-XXXXXXXXXX"
};
```

6. **Copia estos valores** y pégalos en:
   ```
   js/firebase/firebase.js  →  línea 14 (const firebaseConfig = {...})
   ```

---

## PASO 3 — ACTIVAR FIREBASE AUTHENTICATION

1. En el menú izquierdo → **Authentication** → **Comenzar**
2. Pestaña **"Sign-in method"**
3. Activa **"Correo electrónico/contraseña"**
4. **NO** actives "Vínculo de correo sin contraseña"

### Cómo crear un cliente nuevo:

**Opción A — Desde Firebase Console (manual):**
1. Authentication → Users → **"Agregar usuario"**
2. Correo: `pb-2025-001@poolbalance.cliente`
3. Contraseña: `847291` (el PIN de 6 dígitos que tú elijas)

**Opción B — Desde Apps Script (automático):**
```javascript
// En tu Google Apps Script — Admin SDK
const auth = admin.auth();
await auth.createUser({
  email:    `${clienteId.toLowerCase()}@poolbalance.cliente`,
  password: pin,
  displayName: nombreCliente,
});
```

### 🔑 Generador de PIN seguro (copia y usa en Sheets):
```javascript
// En una celda de Google Sheets con Apps Script:
function generarPin() {
  const array = new Uint32Array(1);
  crypto.getRandomValues(array);
  return String(array[0] % 900000 + 100000);
}
// O más simple:
=TEXT(RANDBETWEEN(100000, 999999), "000000")
```

---

## PASO 4 — CONFIGURAR CLOUD FIRESTORE

1. Menú → **Firestore Database** → **"Crear base de datos"**
2. Modo: **"Producción"** (recomendado)
3. Ubicación: **`us-central1`** (o `nam5` para América)
4. Clic en **"Crear"**

### Reglas de Seguridad (pegar en la pestaña "Reglas"):

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Un cliente solo puede leer SU propio documento
    match /clientes/{clienteId} {
      allow read: if request.auth != null
                  && request.auth.token.email ==
                     clienteId.lower() + "@poolbalance.cliente";
      allow write: if false; // Solo el admin puede escribir
    }

    // Un cliente solo puede leer SUS propias albercas y bitácoras
    match /clientes/{clienteId}/albercas/{albercaId} {
      allow read: if request.auth != null
                  && request.auth.token.email ==
                     clienteId.lower() + "@poolbalance.cliente";
    }

    match /clientes/{clienteId}/albercas/{albercaId}/bitacoras/{bitacoraId} {
      allow read: if request.auth != null
                  && request.auth.token.email ==
                     clienteId.lower() + "@poolbalance.cliente";
      allow write: if false; // Solo Apps Script escribe aquí
    }
  }
}
```

---

## PASO 5 — ESQUEMA DE COLECCIONES FIRESTORE

### Estructura completa (cópiala como referencia):

```
📁 clientes/
  └── 📄 PB-2025-001          ← ID del documento = ID del cliente
        ├── nombre:           "Familia García Reyes"
        ├── plan:             "Balance"
        ├── direccion:        "Fracc. Costa Verde, Boca del Río"
        ├── telefono:         "2291234567"
        ├── volumen_m3:       "62 m³"
        ├── proxima_visita:   "2025-07-15"
        ├── cliente_desde:    "Enero 2025"
        ├── alberca_id:       "principal"     ← nombre de su alberca
        └── activo:           true

        └── 📁 albercas/
              └── 📄 principal
                    ├── volumen_m3:     62
                    ├── tipo_acabado:   "Azulejo"
                    ├── tipo_filtro:    "Arena"
                    ├── equipo_bomba:   "Pentair 1.5HP"
                    └── capacidad_L:   62000

                    └── 📁 bitacoras/
                          └── 📄 2025-06-28    ← fecha = ID del doc
                                ├── fecha:             "2025-06-28"
                                ├── tecnico:           "Ing. Omar Castillo"
                                ├── estado:            "optimo"
                                ├── lecturas: {
                                │     ph:               7.4,
                                │     cloro_libre:      2.1,
                                │     cloro_combinado:  0.2,
                                │     alcalinidad:      105,
                                │     dureza_calcica:   280,
                                │     lsi:              0.1,
                                │     temperatura:      29,
                                │     estabilizador:    42
                                │   }
                                ├── acciones: [
                                │     "Ajuste de pH con ácido muriático",
                                │     "Retrolavado del filtro de arena",
                                │     "Limpieza de canastillas"
                                │   ]
                                ├── notas:             "Alberca en condiciones óptimas."
                                ├── fotos: [
                                │     "https://storage.googleapis.com/pool-balance.../foto1.jpg",
                                │     "https://drive.google.com/uc?id=XXXX"
                                │   ]
                                ├── pdf_url:           "https://storage.../reporte.pdf"
                                ├── litros_retrolav:   180
                                ├── litros_evap:       210
                                └── quimicos_usados: {
                                      acido_mur_lt:    0.5,
                                      cloro_kg:        0.3,
                                      bicarbonato_kg:  0.0
                                    }
```

---

## PASO 6 — FIREBASE STORAGE (Fotos)

1. Menú → **Storage** → **"Comenzar"**
2. Modo producción → ubicación `us-central1`

### Reglas de Storage:
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Solo usuarios autenticados pueden leer fotos
    match /clientes/{clienteId}/{allPaths=**} {
      allow read:  if request.auth != null;
      allow write: if false; // Solo tú (admin) sube fotos
    }
  }
}
```

### Estructura de carpetas en Storage:
```
📁 clientes/
  └── 📁 PB-2025-001/
        └── 📁 2025-06-28/      ← fecha del servicio
              ├── foto_01.jpg
              ├── foto_02.jpg
              └── foto_03.jpg
```

### Cómo obtener URLs públicas de Google Drive (alternativa más rápida):
```
1. Sube la foto a Google Drive
2. Clic derecho → "Obtener enlace" → "Cualquier persona con el enlace"
3. El enlace es: https://drive.google.com/file/d/XXXXX/view
4. Para usarlo como imagen directa, transforma a:
   https://drive.google.com/uc?export=view&id=XXXXX
5. Pega esa URL en el array "fotos" de la bitácora en Firestore
```

---

## PASO 7 — APPS SCRIPT: GOOGLE SHEETS → FIRESTORE

### Conectar tu Libro Maestro de Sheets con Firestore:

**1. Instalar FirebaseApp library en Apps Script:**
```
En tu proyecto de Apps Script:
Recursos → Bibliotecas → Agregar:
ID: 1VlYLzhx9_LFHJGkWBFxKRdlzeRYGGIUPQdxQ4cPnRBbVaNWxBqPAOgj
```

**2. Script de exportación de bitácora (pegar en tu Apps Script):**

```javascript
/**
 * Exporta una fila del Libro Maestro a Firestore
 * Llama esta función desde tu flujo de Gemini o manualmente
 */
function exportarBitacoraAFirestore(clienteId, albercaId, datosRow) {
  const projectId = 'pool-balance';

  // Construir objeto de la bitácora
  const bitacora = {
    fecha:            datosRow.fecha,            // "2025-06-28"
    tecnico:          datosRow.tecnico,
    estado:           datosRow.estado,           // "optimo" | "corregido" | "alerta"
    lecturas: {
      ph:               parseFloat(datosRow.ph),
      cloro_libre:      parseFloat(datosRow.cloro_libre),
      cloro_combinado:  parseFloat(datosRow.cloro_combinado),
      alcalinidad:      parseFloat(datosRow.alcalinidad),
      dureza_calcica:   parseFloat(datosRow.dureza_calcica),
      lsi:              parseFloat(datosRow.lsi),
      temperatura:      parseFloat(datosRow.temperatura) || null,
      estabilizador:    parseFloat(datosRow.estabilizador) || null,
    },
    acciones:         datosRow.acciones.split(',').map(a => a.trim()),
    notas:            datosRow.notas,
    fotos:            datosRow.fotos ? datosRow.fotos.split(',').map(f => f.trim()) : [],
    litros_retrolav:  parseFloat(datosRow.litros_retrolav) || 0,
    litros_evap:      parseFloat(datosRow.litros_evap) || 0,
    quimicos_usados: {
      acido_mur_lt:   parseFloat(datosRow.acido_mur_lt) || 0,
      cloro_kg:       parseFloat(datosRow.cloro_kg) || 0,
      bicarbonato_kg: parseFloat(datosRow.bicarbonato_kg) || 0,
    },
    updated_at: new Date().toISOString(),
  };

  // Path en Firestore: clientes/{id}/albercas/{alberca}/bitacoras/{fecha}
  const path = `clientes/${clienteId}/albercas/${albercaId}/bitacoras/${bitacora.fecha}`;

  // Usar Firebase REST API (no requiere Admin SDK)
  const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/${path}`;

  const payload = _toFirestoreDoc(bitacora);

  const options = {
    method:      'PATCH',   // PATCH = crear o actualizar (upsert)
    contentType: 'application/json',
    headers:     { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
    payload:     JSON.stringify(payload),
    muteHttpExceptions: true,
  };

  const response = UrlFetchApp.fetch(url, options);
  const code     = response.getResponseCode();

  if (code === 200 || code === 201) {
    Logger.log(`✅ Bitácora ${bitacora.fecha} exportada para ${clienteId}`);
    return true;
  } else {
    Logger.log(`❌ Error ${code}: ${response.getContentText()}`);
    return false;
  }
}

/**
 * Convierte un objeto JS plano al formato de documento Firestore REST API
 */
function _toFirestoreDoc(obj) {
  const fields = {};
  for (const [key, val] of Object.entries(obj)) {
    if (val === null || val === undefined) continue;
    if (typeof val === 'string')  fields[key] = { stringValue: val };
    else if (typeof val === 'number') fields[key] = { doubleValue: val };
    else if (typeof val === 'boolean') fields[key] = { booleanValue: val };
    else if (Array.isArray(val)) {
      fields[key] = {
        arrayValue: {
          values: val.map(v =>
            typeof v === 'string' ? { stringValue: v } : { doubleValue: v }
          )
        }
      };
    } else if (typeof val === 'object') {
      fields[key] = { mapValue: { fields: _toFirestoreDoc(val).fields } };
    }
  }
  return { fields };
}

/**
 * Ejemplo de cómo llamarlo desde el trigger de tu Gemini:
 */
function onNuevaBitacora() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet()
                              .getSheetByName('Bitácoras');
  const lastRow = sheet.getLastRow();
  const data    = sheet.getRange(lastRow, 1, 1, 20).getValues()[0];

  // Mapear columnas de tu Sheet a campos de la bitácora
  const datosRow = {
    fecha:           data[0],   // Columna A
    tecnico:         data[1],   // Columna B
    ph:              data[2],   // Columna C
    cloro_libre:     data[3],   // Columna D
    cloro_combinado: data[4],   // Columna E
    alcalinidad:     data[5],   // Columna F
    dureza_calcica:  data[6],   // Columna G
    lsi:             data[7],   // Columna H
    temperatura:     data[8],   // Columna I
    estabilizador:   data[9],   // Columna J
    litros_retrolav: data[10],  // Columna K
    litros_evap:     data[11],  // Columna L
    acido_mur_lt:    data[12],  // Columna M
    cloro_kg:        data[13],  // Columna N
    bicarbonato_kg:  data[14],  // Columna O
    acciones:        data[15],  // Columna P (separadas por coma)
    notas:           data[16],  // Columna Q
    fotos:           data[17],  // Columna R (URLs separadas por coma)
    estado:          data[18],  // Columna S: "optimo"|"corregido"|"alerta"
  };

  const clienteId = data[19]; // Columna T: "PB-2025-001"

  exportarBitacoraAFirestore(clienteId, 'principal', datosRow);
}
```

---

## PASO 8 — FIREBASE HOSTING (Dominio .mx)

```bash
# 1. Instalar Firebase CLI
npm install -g firebase-tools

# 2. Login con tu cuenta Google
firebase login

# 3. En la carpeta del proyecto
firebase init hosting

# Configuración:
# - Public directory: . (punto — la raíz del proyecto)
# - Single-page app: YES
# - No sobrescribir index.html

# 4. Crear firebase.json en la raíz:
```

**`firebase.json`** (crear en la raíz del proyecto):
```json
{
  "hosting": {
    "public": ".",
    "ignore": [
      "firebase.json",
      "**/.*",
      "**/node_modules/**",
      "FIREBASE_SETUP.md",
      "README.md"
    ],
    "rewrites": [
      { "source": "**", "destination": "/index.html" }
    ],
    "headers": [
      {
        "source": "**/*.@(js|css)",
        "headers": [{ "key": "Cache-Control", "value": "max-age=31536000" }]
      },
      {
        "source": "sw.js",
        "headers": [{ "key": "Cache-Control", "value": "no-cache" }]
      }
    ]
  }
}
```

```bash
# 5. Desplegar
firebase deploy --only hosting

# Resultado:
# ✅ Hosting URL: https://pool-balance.web.app

# 6. Conectar dominio .mx personalizado
# Firebase Console → Hosting → "Agregar dominio personalizado"
# Ingresa: poolbalance.mx
# Firebase te dará registros DNS para configurar en tu proveedor
```

---

## PASO 9 — CHECKLIST FINAL

```
FIREBASE CONSOLE:
□ Proyecto "pool-balance" creado
□ App web registrada y firebaseConfig copiada a firebase.js
□ Authentication → Email/Password activado
□ Primer usuario de prueba creado
□ Firestore creado en modo producción
□ Reglas de seguridad de Firestore pegadas
□ Storage creado con reglas
□ Hosting configurado

CÓDIGO:
□ firebaseConfig pegado en js/firebase/firebase.js
□ Primera bitácora de prueba creada manualmente en Firestore
□ Login funcional con el primer cliente

APPS SCRIPT (SHEETS):
□ Script de exportación pegado en tu Libro Maestro
□ Trigger configurado para onNuevaBitacora()
□ Prueba manual exitosa: nueva fila → aparece en la app

DOMINIO .MX:
□ firebase.json creado en raíz del proyecto
□ firebase deploy ejecutado
□ DNS del dominio .mx apuntando a Firebase Hosting
□ HTTPS activo (automático con Firebase)
```

---

## PREGUNTAS FRECUENTES

**¿El cliente puede ver las bitácoras de otro cliente?**
No. Las reglas de Firestore verifican que el email del usuario autenticado corresponda exactamente al clienteId del documento que intenta leer.

**¿Qué pasa si olvido actualizar el PIN de un cliente?**
Vas a Firebase Console → Authentication → Users → selecciona el usuario → "Restablecer contraseña" o edita directamente el campo. También puedes hacerlo desde Apps Script con Admin SDK.

**¿Puedo usar el mismo Firebase de mi otra PWA?**
Sí, puedes crear un segundo proyecto dentro de la misma cuenta de Firebase. O puedes usar el mismo proyecto con distintas colecciones. Recomendamos proyectos separados para mayor claridad.

**¿Las fotos de Google Drive funcionan directamente?**
Sí, con el formato: `https://drive.google.com/uc?export=view&id=XXXXX`. Asegúrate de que el archivo tenga permiso "Cualquier persona con el enlace puede ver".

**¿El plan gratuito de Firebase es suficiente?**
Para 20–50 clientes con bitácoras mensuales, el plan Spark (gratuito) es más que suficiente:
- Firestore: 50K lecturas/día gratis → tus clientes no llegan ni al 1%
- Storage: 5GB gratis
- Hosting: 10GB/mes gratis
- Auth: ilimitado gratis

---

*Pool Balance · Gestoría Técnica de Albercas · Veracruz, México*
*Documento interno — Omar Castillo · 2025*
